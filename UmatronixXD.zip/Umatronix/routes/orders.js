const router = require('express').Router();
const requireAuth = require('../middleware/auth');
const Order = require('../models/Order');

router.post('/', requireAuth, async (req, res, next) => {
  try {
    const incoming = Array.isArray(req.body.items) ? req.body.items : [];
    if (!incoming.length || incoming.length > 50) return res.status(400).json({ message: 'La lista está vacía o tiene demasiados elementos.' });
    const items = incoming.map(line => {
      const name = String(line.name || '').trim().slice(0, 120);
      const category = String(line.category || '').trim().slice(0, 80);
      const unitPrice = Number(line.unitPrice);
      const quantity = Number(line.quantity);
      if (!name || !category || !Number.isFinite(unitPrice) || unitPrice < 0 || !Number.isInteger(quantity) || quantity < 1 || quantity > 99) {
        throw Object.assign(new Error('Hay un producto, precio o cantidad no válida.'), { status: 400 });
      }
      return { name, category, unitPrice, quantity };
    });
    const total = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
    const order = await Order.create({ user: req.session.user.id, items, total });
    res.status(201).json({ message: 'Pedido registrado correctamente.', order });
  } catch (err) { next(err); }
});
router.get('/mine', requireAuth, async (req, res, next) => {
  try { const orders = await Order.find({ user: req.session.user.id }).sort({ createdAt: -1 }).lean(); res.json({ orders }); }
  catch (err) { next(err); }
});
module.exports = router;
