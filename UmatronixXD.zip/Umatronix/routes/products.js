const router = require('express').Router();
const Product = require('../models/Product');
router.get('/', async (req, res, next) => {
  try { res.json({ products: await Product.find({ active: true }).sort({ createdAt: -1 }).lean() }); }
  catch (err) { next(err); }
});
module.exports = router;
