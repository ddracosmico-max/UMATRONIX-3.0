const router = require('express').Router();
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const User = require('../models/User');
const requireAuth = require('../middleware/auth');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false
});

const publicUser = user => ({
  id: user._id,
  name: user.name,
  email: user.email,
  role: user.role
});

function startUserSession(req, user, res, next, status = 200) {
  req.session.regenerate(err => {
    if (err) return next(err);
    req.session.user = publicUser(user);
    req.session.save(saveError => {
      if (saveError) return next(saveError);
      res.status(status).json({ user: publicUser(user) });
    });
  });
}

router.post('/register', limiter, async (req, res, next) => {
  try {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');

    if (name.length < 2 || name.length > 80) {
      return res.status(400).json({ message: 'Escribe un nombre válido (2 a 80 caracteres).' });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ message: 'Escribe un correo válido.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ message: 'La contraseña debe tener al menos 8 caracteres.' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({ name, email, passwordHash });
    startUserSession(req, user, res, next, 201);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ message: 'Ese correo ya está registrado.' });
    }
    next(err);
  }
});

router.post('/login', limiter, async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const user = await User.findOne({ email }).select('+passwordHash');

    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      return res.status(401).json({ message: 'Correo o contraseña incorrectos.' });
    }

    startUserSession(req, user, res, next);
  } catch (err) {
    next(err);
  }
});

router.get('/me', (req, res) => {
  res.json({ user: req.session.user || null });
});

router.post('/logout', requireAuth, (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ message: 'No se pudo cerrar la sesión.' });
    res.clearCookie('umatronix.sid', {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production'
    });
    res.json({ message: 'Sesión cerrada.' });
  });
});

module.exports = router;
