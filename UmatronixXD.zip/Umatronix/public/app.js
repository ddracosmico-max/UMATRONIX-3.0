(() => {
  'use strict';
  const categories = ["Celulares","Computación","Audio y TV","Videojuegos","Electrodomésticos","Hogar","Cocina","Muebles","Moda Mujer","Moda Hombre","Calzado","Accesorios","Deportes","Belleza","Salud y Bienestar","Juguetes","Bebés","Mascotas","Libros","Papelería","Herramientas","Automotriz","Jardín","Supermercado","Instrumentos"];
  const $ = id => document.getElementById(id);

  // Configuración visual de Umatronix: fondo e identidad de color.
  const SETTINGS_KEY = 'umatronix.settings.v1';
  const LEGACY_BACKGROUND_KEY = 'umatronix.background.v1';
  const settingsDialog = $('settingsDialog');
  const settingsBackground = $('settingsBackground');
  const pageColor = $('pageColor');
  const brandColor = $('brandColor');
  const DEFAULT_PAGE_COLOR = '#f5f5f5';
  const DEFAULT_BRAND_COLOR = '#ffe600';
  let selectedSettingsBackground = '';
  const soundsEnabledInput = $('soundsEnabled');
  const catalogSoundInput = $('catalogSoundInput');
  const purchaseSoundInput = $('purchaseSoundInput');
  const SOUND_STORAGE_KEY = 'umatronix.customSounds.v1';

  function loadCustomSounds() {
    try {
      const saved = JSON.parse(localStorage.getItem(SOUND_STORAGE_KEY) || '{}');
      return {
        catalog: typeof saved.catalog === 'string' && saved.catalog.startsWith('data:audio/') ? saved.catalog : '',
        purchase: typeof saved.purchase === 'string' && saved.purchase.startsWith('data:audio/') ? saved.purchase : ''
      };
    } catch {
      return { catalog: '', purchase: '' };
    }
  }

  const customSounds = loadCustomSounds();
  const MAX_SOUND_SIZE = 1024 * 1024; // 1 MB por audio para cuidar el almacenamiento local.

  function playCustomSound(type) {
    if (!soundsEnabledInput || !soundsEnabledInput.checked) return;
    const source = customSounds[type];
    if (!source) return;
    const audio = new Audio(source);
    audio.volume = 0.7;
    audio.play().catch(() => {
      // Algunos navegadores bloquean el audio hasta que el usuario interactúe con la página.
    });
  }

  function readSoundFile(input, type) {
    const file = input.files && input.files[0];
    if (!file) return;
    if (!file.type.startsWith('audio/')) {
      alert('Selecciona un archivo de audio válido.');
      input.value = '';
      return;
    }
    if (file.size > MAX_SOUND_SIZE) {
      alert('El audio supera 1 MB. Elige un archivo más pequeño para guardarlo en el navegador.');
      input.value = '';
      return;
    }
    const reader = new FileReader();
    reader.addEventListener('load', () => {
      const result = String(reader.result || '');
      if (result.startsWith('data:audio/')) {
        customSounds[type] = result;
        try {
          localStorage.setItem(SOUND_STORAGE_KEY, JSON.stringify(customSounds));
        } catch {
          alert('No se pudo guardar el audio. Prueba con un archivo más pequeño.');
          customSounds[type] = '';
        }
      }
    });
    reader.addEventListener('error', () => alert('No se pudo leer el audio. Intenta con otro archivo.'));
    reader.readAsDataURL(file);
  }

  function previewCustomSound(type) {
    const source = customSounds[type];
    if (!source) {
      alert('Primero selecciona un audio para esta opción.');
      return;
    }
    const audio = new Audio(source);
    audio.volume = 0.7;
    audio.play().catch(() => alert('No se pudo reproducir el audio. Intenta nuevamente.'));
  }

  function applyBackgroundImage(src) {
    document.body.style.backgroundImage = src && src.startsWith('data:image/') ? `url("${src}")` : 'none';
  }

  function loadSettings() {
    try {
      const saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}');
      const legacyBackground = localStorage.getItem(LEGACY_BACKGROUND_KEY) || '';
      const background = typeof saved.background === 'string' && saved.background.startsWith('data:image/') ? saved.background : legacyBackground;
      if (saved.pageColor) {
        document.documentElement.style.setProperty('--page', saved.pageColor);
        pageColor.value = saved.pageColor;
      } else pageColor.value = DEFAULT_PAGE_COLOR;
      if (saved.brandColor) {
        document.documentElement.style.setProperty('--yellow', saved.brandColor);
        document.documentElement.style.setProperty('--yellow-deep', saved.brandColor);
        brandColor.value = saved.brandColor;
      } else brandColor.value = DEFAULT_BRAND_COLOR;
      if (background) applyBackgroundImage(background);
      selectedSettingsBackground = background || '';
      if (soundsEnabledInput) soundsEnabledInput.checked = saved.soundsEnabled !== false;
    } catch (error) {
      console.warn('No se pudieron cargar los ajustes de Umatronix.');
    }
  }

  if (settingsDialog && $('openSettings')) {
    $('openSettings').addEventListener('click', () => settingsDialog.showModal());
    $('closeSettings').addEventListener('click', () => settingsDialog.close());
    settingsDialog.addEventListener('click', event => { if (event.target === settingsDialog) settingsDialog.close(); });
    pageColor.addEventListener('input', () => document.documentElement.style.setProperty('--page', pageColor.value));
    brandColor.addEventListener('input', () => {
      document.documentElement.style.setProperty('--yellow', brandColor.value);
      document.documentElement.style.setProperty('--yellow-deep', brandColor.value);
    });
    settingsBackground.addEventListener('change', () => {
      const file = settingsBackground.files && settingsBackground.files[0];
      if (!file) return;
      if (!file.type.startsWith('image/')) {
        alert('Selecciona una imagen válida.'); settingsBackground.value = ''; return;
      }
      if (file.size > 4 * 1024 * 1024) {
        alert('La imagen supera 4 MB. Elige una imagen más pequeña para poder guardarla en el navegador.');
        settingsBackground.value = ''; return;
      }
      const reader = new FileReader();
      reader.addEventListener('load', () => {
        const result = String(reader.result || '');
        if (!result.startsWith('data:image/')) return;
        selectedSettingsBackground = result;
        applyBackgroundImage(result);
      });
      reader.addEventListener('error', () => alert('No se pudo leer la imagen. Intenta con otra.'));
      reader.readAsDataURL(file);
    });

    catalogSoundInput.addEventListener('change', () => readSoundFile(catalogSoundInput, 'catalog'));
    purchaseSoundInput.addEventListener('change', () => readSoundFile(purchaseSoundInput, 'purchase'));
    $('previewNavigationSound').addEventListener('click', () => previewCustomSound('catalog'));
    $('previewPurchaseSound').addEventListener('click', () => previewCustomSound('purchase'));

    $('settingsForm').addEventListener('submit', event => {
      event.preventDefault();
      const settings = {
        pageColor: pageColor.value,
        brandColor: brandColor.value,
        background: selectedSettingsBackground,
        soundsEnabled: soundsEnabledInput.checked,
      };
      try {
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
        if (selectedSettingsBackground) localStorage.setItem(LEGACY_BACKGROUND_KEY, selectedSettingsBackground);
        else localStorage.removeItem(LEGACY_BACKGROUND_KEY);
        settingsDialog.close();
      } catch (error) {
        alert('No se pudieron guardar los ajustes. Prueba con una imagen más pequeña.');
      }
    });
    $('resetSettings').addEventListener('click', () => {
      pageColor.value = DEFAULT_PAGE_COLOR; brandColor.value = DEFAULT_BRAND_COLOR;
      settingsBackground.value = ''; selectedSettingsBackground = '';
      catalogSoundInput.value = ''; purchaseSoundInput.value = '';
      customSounds.catalog = ''; customSounds.purchase = '';
      localStorage.removeItem(SOUND_STORAGE_KEY);
      soundsEnabledInput.checked = true;
      document.documentElement.style.setProperty('--page', DEFAULT_PAGE_COLOR);
      document.documentElement.style.setProperty('--yellow', DEFAULT_BRAND_COLOR);
      document.documentElement.style.setProperty('--yellow-deep', '#f2d900');
      applyBackgroundImage('');
      localStorage.removeItem(SETTINGS_KEY); localStorage.removeItem(LEGACY_BACKGROUND_KEY);
    });
  }
  loadSettings();

  const grid = $('itemsGrid'), empty = $('emptyState'), addDialog = $('addDialog'), listDialog = $('listDialog'), confirmDialog = $('confirmDialog');
  const select = $('elementCategory');
  let activeCategory = 'Todas';
  let searchTerm = '';
  let deleteTarget = null;
  const STORAGE_KEY = 'umatronix.catalog.v3';
  const safe = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));


// =============================================
// UMATRONIX - SISTEMA DE OFERTAS FLASH DIARIAS
// =============================================

const dailyDeals = [
  {
    name: "Audífonos inalámbricos",
    image: "images/ofertas/audifonos.jpg",
    originalPrice: 120000,
    discount: 25
  },
  {
    name: "Control inalámbrico para videojuegos",
    image: "images/ofertas/control.jpg",
    originalPrice: 180000,
    discount: 20
  },
  {
    name: "Reloj inteligente",
    image: "images/ofertas/reloj.jpg",
    originalPrice: 250000,
    discount: 30
  },
  {
    name: "Teclado mecánico RGB",
    image: "images/ofertas/teclado.jpg",
    originalPrice: 160000,
    discount: 15
  },
  {
    name: "Parlante Bluetooth",
    image: "images/ofertas/parlante.jpg",
    originalPrice: 200000,
    discount: 35
  },
  {
    name: "Mouse gamer",
    image: "images/ofertas/mouse.jpg",
    originalPrice: 100000,
    discount: 20
  }
];

// Calcula qué productos corresponden al día actual.
function getTodayDeals() {
  const now = new Date();

  const startOfYear = new Date(now.getFullYear(), 0, 1);
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const dayNumber = Math.floor(
    (today - startOfYear) / 86400000
  );

  const firstIndex = (dayNumber * 3) % dailyDeals.length;

  return [
    dailyDeals[firstIndex],
    dailyDeals[(firstIndex + 1) % dailyDeals.length],
    dailyDeals[(firstIndex + 2) % dailyDeals.length]
  ];
}

// Dibuja las tarjetas de ofertas.
function renderDailyDeals() {
  const container = $('dailyDealsGrid');
  if (!container) return;

  const products = getTodayDeals();

  container.innerHTML = products.map(product => {
    const finalPrice = Math.round(
      product.originalPrice * (1 - product.discount / 100)
    );

    const savings = product.originalPrice - finalPrice;

    return `
      <article class="daily-deal-card">

        <div class="daily-deal-image">
          <span class="daily-discount">
            -${product.discount}%
          </span>

          <img
            src="${safe(product.image)}"
            alt="${safe(product.name)}"
            onerror="this.style.display='none'"
          >
        </div>

        <div class="daily-deal-info">

          <span class="daily-deal-label">
            ⚡ OFERTA DEL DÍA
          </span>

          <h3>${safe(product.name)}</h3>

          <div class="daily-old-price">
            ${formatPrice(product.originalPrice)}
          </div>

          <div class="daily-new-price">
            ${formatPrice(finalPrice)}
          </div>

          <div class="daily-savings">
            Ahorras ${formatPrice(savings)}
          </div>

        </div>
      </article>
    `;
  }).join('');
}

// Contador hasta la medianoche local.
function updateDailyCountdown() {
  const countdown = $('dailyCountdown');
  if (!countdown) return;

  const now = new Date();

  const midnight = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() + 1
  );

  const remaining = Math.max(0, midnight - now);

  const hours = Math.floor(remaining / 3600000);
  const minutes = Math.floor((remaining % 3600000) / 60000);
  const seconds = Math.floor((remaining % 60000) / 1000);

  countdown.textContent = [
    String(hours).padStart(2, '0'),
    String(minutes).padStart(2, '0'),
    String(seconds).padStart(2, '0')
  ].join(':');
}

// Actualización automática de las ofertas.


// =============================================
// FIN DEL SISTEMA DE OFERTAS FLASH
// =============================================


  function makeId(){ return Date.now().toString(36) + Math.random().toString(36).slice(2,8); }
  const formatPrice = value => new Intl.NumberFormat('es-CO', {
    style: 'currency', currency: 'COP', maximumFractionDigits: 0
  }).format(Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : 0);


  function createCatalogMap(){
    const map = {};
    categories.forEach(name => { map[name] = []; });
    return map;
  }

  function normalizeItem(item){
    if (!item || typeof item !== 'object') return null;
    const name = typeof item.name === 'string' ? item.name.trim() : '';
    if (!name) return null;

    const category = typeof item.category === 'string' && categories.includes(item.category)
      ? item.category
      : categories[0];

    return {
      id: typeof item.id === 'string' && item.id ? item.id : makeId(),
      name,
      category,
      price: Number.isFinite(Number(item.price)) && Number(item.price) >= 0 ? Number(item.price) : 0,
      inList: Boolean(item.inList),
      image: typeof item.image === 'string' && item.image.startsWith('data:image/') ? item.image : ''
    };
  }

  function loadCatalogs(){
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      const map = createCatalogMap();
      if (stored === null) {
        // Primer uso: inicia vacío para que la persona agregue sus propios elementos.
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(map)); } catch (e) {}
        return map;
      }
      const raw = JSON.parse(stored || '{}');

      if (Array.isArray(raw)) {
        raw.forEach(item => {
          const normalized = normalizeItem(item);
          if (!normalized) return;
          if (!map[normalized.category]) map[normalized.category] = [];
          map[normalized.category].push(normalized);
        });
        return map;
      }

      if (raw && typeof raw === 'object') {
        categories.forEach(category => {
          const items = Array.isArray(raw[category]) ? raw[category] : [];
          map[category] = items.map(normalizeItem).filter(Boolean);
        });
      }

      return map;
    } catch (error) {
      return createCatalogMap();
    }
  }

  let catalogs = loadCatalogs();
  let items = [];

  function getAllItems(){
    return categories.reduce((all, category) => all.concat(catalogs[category] || []), []);
  }

  function persist(){
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(catalogs));
    } catch (error) {
      alert('No se pudo guardar en el navegador (posiblemente por exceso de imágenes). Prueba con imágenes más pequeñas.');
    }
  }

  // Búsqueda: ignora mayúsculas y tildes; todas las palabras deben aparecer en nombre, categoría o precio.
  const normalizeText = text => String(text).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  function searchItems(query){
    const terms = normalizeText(query).split(/\s+/).filter(Boolean);
    return getAllItems().filter(item => {
      const haystack = normalizeText(`${item.name} ${item.category} ${item.price}`);
      return terms.every(term => haystack.includes(term));
    });
  }

  function getCategoryItems(category){
    return category === 'Todas' ? getAllItems() : (catalogs[category] || []);
  }

  function findItemById(id){
    return getAllItems().find(item => item.id === id) || null;
  }

  function findCategoryForItem(id){
    return categories.find(category => (catalogs[category] || []).some(item => item.id === id)) || null;
  }

  categories.forEach(name => {
    const option = document.createElement('option');
    option.value = name;
    option.textContent = name;
    select.appendChild(option);
  });

  function render() {
    items = getAllItems();

    // Cuando hay una búsqueda, buscar en TODO el catálogo, no solo en
    // la categoría que estaba seleccionada antes de escribir.
    let shown = searchTerm
      ? searchItems(searchTerm)
      : getCategoryItems(activeCategory);

    grid.innerHTML = shown.map(item => `
      <article class="item-card">
        ${item.image ? `
          <img class="item-image" src="${item.image}" alt="${safe(item.name)}">
        ` : ''}

        <div class="item-card-top">
          <div>
            <div class="item-name">${safe(item.name)}</div>
            <p class="item-price">${formatPrice(item.price)}</p>
            <div class="item-category">${safe(item.category)}</div>
          </div>
        </div>

        <div class="item-actions">
          <button
            type="button"
            class="small-action ${item.inList ? 'selected' : ''}"
            data-action="list"
            data-id="${safe(item.id)}"
          >
            ${item.inList ? 'En mi lista' : 'Agregar a lista'}
          </button>

          <button type="button" class="small-action" data-action="edit" data-id="${safe(item.id)}">
            Editar
          </button>

          <button type="button" class="small-action remove" data-action="delete" data-id="${safe(item.id)}">
            Eliminar
          </button>
        </div>
      </article>
    `).join('');

    const hasItems = shown.length > 0;
    empty.classList.toggle('hidden', hasItems);

    $('summary').textContent =
      `${shown.length} ${shown.length === 1 ? 'resultado' : 'resultados'}`;

    $('itemCount').textContent =
      items.filter(item => item.inList).length;

    $('activeCaption').textContent = searchTerm
      ? `Resultados en todo el catálogo para: "${searchTerm}"`
      : activeCategory === 'Todas'
        ? 'Explora las categorías de la tienda.'
        : `Categoría: ${activeCategory}`;

    $('clearFilter').hidden = activeCategory === 'Todas' && !searchTerm;

    if (searchTerm) {
      $('emptyTitle').textContent = 'No encontramos resultados';
      $('emptyText').textContent =
        'Prueba buscando otro nombre o seleccionando una categoría.';
    } else if (activeCategory === 'Todas') {
      $('emptyTitle').textContent = 'Tu catálogo está vacío';
      $('emptyText').textContent =
        'Agrega un elemento cuando estés listo y asígnalo a una categoría.';
    } else {
      $('emptyTitle').textContent =
        `Todavía no hay elementos en ${activeCategory}`;
      $('emptyText').textContent =
        'Puedes agregar un elemento directamente a esta categoría.';
    }

    renderList();
  }

  let currentImage = '';
  const imageInput = $('elementImage'), imagePreview = $('imagePreview'), imagePreviewBox = $('imagePreviewBox');
  function setImage(src){
    currentImage = src || '';
    imagePreview.src = currentImage;
    imagePreviewBox.hidden = !currentImage;
  }
  // Reduce la imagen para que quepa en el almacenamiento del navegador.
  function resizeImage(file, callback){
    const reader = new FileReader();
    reader.addEventListener('load', () => {
      const img = new Image();
      img.addEventListener('load', () => {
        const max = 600;
        const ratio = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * ratio);
        canvas.height = Math.round(img.height * ratio);
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        callback(canvas.toDataURL('image/jpeg', 0.8));
      });
      img.addEventListener('error', () => alert('No se pudo leer la imagen. Intenta con otra.'));
      img.src = String(reader.result || '');
    });
    reader.addEventListener('error', () => alert('No se pudo leer la imagen. Intenta con otra.'));
    reader.readAsDataURL(file);
  }
  imageInput.addEventListener('change', () => {
    const file = imageInput.files && imageInput.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { alert('Selecciona un archivo de imagen válido.'); imageInput.value = ''; return; }
    resizeImage(file, setImage);
    imageInput.value = '';
  });
  $('removeImage').addEventListener('click', () => setImage(''));

  function openAdd(item = null){
    setImage(item ? item.image : '');
    $('addForm').dataset.editing = item ? item.id : '';
    $('elementName').value = item ? item.name : '';
    $('elementPrice').value = item ? String(item.price ?? 0) : '';
    select.value = item ? item.category : (activeCategory === 'Todas' ? categories[0] : activeCategory);
    $('addDialog').querySelector('h2').textContent = item ? 'Editar elemento' : 'Agregar elemento';
    $('addForm').querySelector('button[type="submit"]').textContent = item ? 'Guardar cambios' : 'Guardar elemento';
    addDialog.showModal();
    requestAnimationFrame(() => $('elementName').focus());
  }

  function closeAdd(){ addDialog.close(); }
  const loginDialog = $('loginDialog');
  let authMode = 'login';
  let currentUser = null;
  async function apiRequest(url, options = {}) {
    const response = await fetch(url, { credentials: 'same-origin', headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, ...options });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || 'No se pudo completar la solicitud.');
    return data;
  }
  function showAuthNotice(message) {
    $('loginNotice').textContent = message;
    $('loginNotice').hidden = false;
  }
  function setAuthMode(mode) {
    authMode = mode;
    const registering = mode === 'register';
    $('registerNameLabel').hidden = !registering;
    $('registerName').hidden = !registering;
    $('registerName').required = registering;
    $('loginPassword').minLength = registering ? 8 : 1;
    $('loginPassword').autocomplete = registering ? 'new-password' : 'current-password';
    $('loginDialog').querySelector('h2').textContent = registering ? 'Crear cuenta' : 'Iniciar sesión';
    $('loginDialog').querySelector('button[type="submit"]').textContent = registering ? 'Registrarme' : 'Continuar';
    $('toggleAuthMode').textContent = registering ? '¿Ya tienes cuenta? Inicia sesión' : '¿No tienes cuenta? Regístrate';
    $('loginModeHelp').textContent = registering ? 'Crea una cuenta para guardar tus compras.' : 'Accede a tu cuenta de Umatronix.';
    $('loginNotice').hidden = true;
  }
  async function refreshCurrentUser() {
    try {
      const data = await apiRequest('/api/auth/me');
      currentUser = data.user;
      $('openLogin').textContent = currentUser ? `Hola, ${currentUser.name}` : 'Iniciar sesión';
    } catch {
      currentUser = null;
      $('openLogin').textContent = 'Iniciar sesión';
    }
  }
  $('openLogin').addEventListener('click', async () => {
    if (currentUser) {
      if (confirm(`¿Deseas cerrar la sesión de ${currentUser.name}?`)) {
        try { await apiRequest('/api/auth/logout', { method: 'POST' }); currentUser = null; await refreshCurrentUser(); alert('Sesión cerrada.'); }
        catch (error) { alert(error.message); }
      }
      return;
    }
    setAuthMode('login');
    $('loginForm').reset();
    loginDialog.showModal();
  });
  $('toggleAuthMode').addEventListener('click', () => setAuthMode(authMode === 'login' ? 'register' : 'login'));
  $('closeLogin').addEventListener('click', () => loginDialog.close());
  $('cancelLogin').addEventListener('click', () => loginDialog.close());
  $('loginForm').addEventListener('submit', async event => {
    event.preventDefault();
    const body = {
      name: $('registerName').value.trim(),
      email: $('loginEmail').value.trim(),
      password: $('loginPassword').value
    };
    try {
      const data = await apiRequest(authMode === 'register' ? '/api/auth/register' : '/api/auth/login', {
        method: 'POST', body: JSON.stringify(body)
      });
      currentUser = data.user;
      $('openLogin').textContent = `Hola, ${currentUser.name}`;
      loginDialog.close();
      $('loginForm').reset();
      alert(authMode === 'register' ? 'Tu cuenta fue creada correctamente.' : 'Sesión iniciada correctamente.');
    } catch (error) { showAuthNotice(error.message); }
  });
  refreshCurrentUser();

  $('openAdd').addEventListener('click', () => openAdd());
  $('emptyAdd').addEventListener('click', () => openAdd());
  $('closeAdd').addEventListener('click', closeAdd);
  $('cancelAdd').addEventListener('click', closeAdd);
  $('addForm').addEventListener('submit', event => {
    event.preventDefault();
    const name = $('elementName').value.trim();
    const priceInput = $('elementPrice');
    const price = Number(priceInput.value);
    if (!name) {
      $('elementName').focus();
      return;
    }
    if (priceInput.value.trim() === '' || !Number.isFinite(price) || price < 0) {
      priceInput.setCustomValidity('Escribe un precio válido igual o mayor que cero.');
      priceInput.reportValidity();
      priceInput.focus();
      return;
    }
    priceInput.setCustomValidity('');

    const editingId = event.currentTarget.dataset.editing;
    const selectedCategory = select.value;

    if (editingId) {
      const current = findItemById(editingId);
      if (current) {
        const oldCategory = current.category;
        if (oldCategory && oldCategory !== selectedCategory) {
          catalogs[oldCategory] = (catalogs[oldCategory] || []).filter(item => item.id !== editingId);
        }

        if (oldCategory && oldCategory === selectedCategory) {
          const targetList = catalogs[selectedCategory] || [];
          const index = targetList.findIndex(item => item.id === editingId);
          if (index >= 0) {
            targetList[index] = { ...targetList[index], name, category: selectedCategory, price, image: currentImage };
          }
        } else {
          const targetList = catalogs[selectedCategory] || [];
          targetList.push({ ...current, name, category: selectedCategory, price, image: currentImage });
          catalogs[selectedCategory] = targetList;
        }
      }
    } else {
      const categoryList = catalogs[selectedCategory] || [];
      categoryList.push({ id: makeId(), name, category: selectedCategory, price, inList: false, image: currentImage });
      catalogs[selectedCategory] = categoryList;
    }

    persist();
    closeAdd();
    render();
  });

  $('categoryBar').addEventListener('click', event => {
    const button = event.target.closest('[data-category]');
    if (!button) return;

    const categoryChanged = activeCategory !== button.dataset.category;
    activeCategory = button.dataset.category;
    searchTerm = '';
    productSearch.value = '';
    if (categoryChanged) playCustomSound('catalog');

    document.querySelectorAll('.category').forEach(el => {
      const active = el === button;
      el.classList.toggle('active', active);

      if (active) {
        el.setAttribute('aria-current', 'true');
      } else {
        el.removeAttribute('aria-current');
      }
    });

    button.scrollIntoView({
      behavior: 'smooth',
      block: 'nearest',
      inline: 'center'
    });

    render();
  });

  const categoryBar = $('categoryBar');
  $('scrollLeft').addEventListener('click', () => categoryBar.scrollBy({ left: -Math.max(280, categoryBar.clientWidth * .7), behavior: 'smooth' }));
  $('scrollRight').addEventListener('click', () => categoryBar.scrollBy({ left: Math.max(280, categoryBar.clientWidth * .7), behavior: 'smooth' }));
  categoryBar.addEventListener('wheel', event => {
    if (Math.abs(event.deltaY) > Math.abs(event.deltaX)) {
      categoryBar.scrollLeft += event.deltaY;
      event.preventDefault();
    }
  }, { passive: false });

  const searchForm = $('searchForm');
  const productSearch = $('productSearch');

  searchForm.addEventListener('submit', event => {
    event.preventDefault();
    searchTerm = productSearch.value.trim();
    render();
  });

  productSearch.addEventListener('input', () => {
    searchTerm = productSearch.value.trim();
    render();
  });

  // Esc borra la búsqueda.
  productSearch.addEventListener('keydown', event => {
    if (event.key === 'Escape' && productSearch.value) {
      productSearch.value = '';
      searchTerm = '';
      render();
    }
  });
  // Atajo: "/" enfoca el buscador (si no se está escribiendo en otro campo).
  document.addEventListener('keydown', event => {
    if (event.key !== '/' || event.ctrlKey || event.metaKey || event.altKey) return;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName) || document.querySelector('dialog[open]')) return;
    event.preventDefault();
    productSearch.focus();
  });

  $('clearFilter').addEventListener('click', () => {
    searchTerm = '';
    productSearch.value = '';

    const all = document.querySelector('[data-category="Todas"]');
    if (all) all.click();
  });
  $('backToTop').addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

  grid.addEventListener('click', event => {
    const button = event.target.closest('[data-action]');
    if (!button) return;

    const item = findItemById(button.dataset.id);
    if (!item) return;

    if (button.dataset.action === 'list') {
      item.inList = !item.inList;
      const category = findCategoryForItem(item.id);
      if (category) {
        const categoryList = catalogs[category] || [];
        const index = categoryList.findIndex(entry => entry.id === item.id);
        if (index >= 0) categoryList[index].inList = item.inList;
      }
      persist();
      render();
    }

    if (button.dataset.action === 'edit') openAdd(item);
    if (button.dataset.action === 'delete') askDelete(item);
  });

  function renderList(){
    const chosen = getAllItems().filter(item => item.inList);
    $('listContents').innerHTML = chosen.length
      ? chosen.map(item => `<div class="list-row"><div><strong>${safe(item.name)}</strong><span>${safe(item.category)} · ${formatPrice(item.price)}</span></div><button type="button" class="small-action remove" data-unlist="${item.id}">Quitar</button></div>`).join('')
      : '<div class="list-empty">Todavía no tienes elementos en tu lista.</div>';
    $('clearList').disabled = chosen.length === 0;
  }

  $('openList').addEventListener('click', () => { renderList(); listDialog.showModal(); });
  $('closeList').addEventListener('click', () => listDialog.close());
  $('listContents').addEventListener('click', event => {
    const button = event.target.closest('[data-unlist]');
    if (!button) return;
    const item = findItemById(button.dataset.unlist);
    if (!item) return;
    item.inList = false;
    const category = findCategoryForItem(item.id);
    if (category) {
      const categoryList = catalogs[category] || [];
      const index = categoryList.findIndex(entry => entry.id === item.id);
      if (index >= 0) categoryList[index].inList = false;
    }
    persist();
    render();
  });

  $('clearList').addEventListener('click', () => {
    categories.forEach(category => {
      (catalogs[category] || []).forEach(item => { item.inList = false; });
    });
    persist();
    render();
  });

  const historyDialog = $('historyDialog');
  $('checkoutList').addEventListener('click', async () => {
    const chosen = getAllItems().filter(item => item.inList);
    if (!chosen.length) { alert('Agrega elementos a Mi lista antes de registrar una compra.'); return; }
    if (!currentUser) {
      alert('Inicia sesión o crea una cuenta para registrar tu compra.');
      setAuthMode('login'); loginDialog.showModal(); return;
    }
    const itemsForOrder = chosen.map(item => ({ name: item.name, category: item.category, unitPrice: item.price, quantity: 1 }));
    const total = itemsForOrder.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
    if (!confirm(`Vas a registrar un pedido por ${formatPrice(total)}. Esto registra el pedido, pero no procesa un pago en línea. ¿Continuar?`)) return;
    try {
      await apiRequest('/api/orders', { method: 'POST', body: JSON.stringify({ items: itemsForOrder }) });
      categories.forEach(category => (catalogs[category] || []).forEach(item => { item.inList = false; }));
      persist(); render(); playCustomSound('purchase');
      alert('¡Pedido registrado! Puedes consultarlo en Mis compras.');
    } catch (error) { alert(error.message); }
  });
  $('historyOrders').addEventListener('click', async () => {
    if (!currentUser) { alert('Inicia sesión para consultar tus compras.'); return; }
    try {
      const data = await apiRequest('/api/orders/mine');
      $('historyContents').innerHTML = data.orders.length ? data.orders.map(order =>
        `<section class="list-row"><div><strong>Pedido · ${new Date(order.createdAt).toLocaleString('es-CO')}</strong><span>${order.items.map(line => `${safe(line.name)} × ${line.quantity}`).join(', ')}</span><strong>${formatPrice(order.total)}</strong></div></section>`
      ).join('') : '<div class="list-empty">Todavía no tienes compras registradas.</div>';
      historyDialog.showModal();
    } catch (error) { alert(error.message); }
  });
  $('closeHistory').addEventListener('click', () => historyDialog.close());

  function askDelete(item){
    deleteTarget = item.id;
    $('confirmText').textContent = `Se eliminará “${item.name}” del catálogo.`;
    confirmDialog.showModal();
  }

  function closeConfirm(){ deleteTarget = null; confirmDialog.close(); }
  $('cancelDelete').addEventListener('click', closeConfirm);
  $('cancelDeleteX').addEventListener('click', closeConfirm);
  $('confirmDelete').addEventListener('click', () => {
    if (deleteTarget) {
      const category = findCategoryForItem(deleteTarget);
      if (category) {
        catalogs[category] = (catalogs[category] || []).filter(item => item.id !== deleteTarget);
      }
      persist();
      render();
    }
    closeConfirm();
  });

  [addDialog, loginDialog, listDialog, historyDialog, confirmDialog].forEach(dialog => dialog.addEventListener('click', event => {
    if (event.target === dialog) dialog.close();
  }));

  // Integración futura: llamar playCustomSound('purchase') únicamente después de confirmar una compra real.
  // Actualmente Umatronix todavía no tiene un flujo de compra; no se reproduce este sonido al agregar elementos.

  // PRUEBA_DE_MODIFICACION_2026_10_21_02_56

  renderDailyDeals();
updateDailyCountdown();

setInterval(() => {
  updateDailyCountdown();
}, 1000);

// Comprueba si cambió el día y actualiza los productos.
let lastDealDate = new Date().toDateString();

setInterval(() => {
  const currentDate = new Date().toDateString();

  if (currentDate !== lastDealDate) {
    lastDealDate = currentDate;
    renderDailyDeals();
    updateDailyCountdown();
  }
}, 10000);
  render();
})();
