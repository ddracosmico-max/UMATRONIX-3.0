const mongoose = require('mongoose');
const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  items: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    name: { type: String, required: true },
    category: String,
    unitPrice: { type: Number, required: true, min: 0 },
    quantity: { type: Number, required: true, min: 1, max: 99 }
  }],
  total: { type: Number, required: true, min: 0 },
  status: { type: String, enum: ['registered','cancelled'], default: 'registered' }
}, { timestamps: true });
module.exports = mongoose.model('Order', orderSchema);
