const mongoose = require('mongoose');

async function connectDatabase() {
  if (!process.env.MONGODB_URI) {
    throw new Error('Falta MONGODB_URI. Configura el archivo .env siguiendo .env.example.');
  }
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('MongoDB conectado correctamente.');
}
module.exports = connectDatabase;
